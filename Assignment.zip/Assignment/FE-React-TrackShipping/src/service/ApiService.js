import axios from 'axios';


class ApiService {

    trackShippingById(shippingId) {
        return axios.get('http://localhost:8080/shipping/'+ shippingId);
    }

    addShipping(shippling) {
       return axios.post("http://localhost:8080/shipping", shippling);
    }
}

export default new ApiService();