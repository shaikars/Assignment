import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class AddShippingComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            idproof: '',
            caddress: '',
            firstName: '',
            lastName: '',
            saddress: '',
            samount: '',
            message: null
        }
        this.saveShipping = this.saveShipping.bind(this);
    }

    saveShipping = (e) => {
        e.preventDefault();
        let shipping = {idproof: this.state.idproof, caddress: this.state.caddress, firstName: this.state.firstName, lastName: this.state.lastName, saddress: this.state.saddress, samount: this.state.samount};
        ApiService.addShipping(shipping)
            .then(res => {
                this.setState({message : 'Shipping created successfully.'});
                this.props.history.push('/');
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return(
            <div>
                <h2 className="text-center">Create Shipping</h2>
                <form>
               

                <div className="form-group">
                    <label>First Name:</label>
                    <input placeholder="First Name" name="firstName" className="form-control" value={this.state.firstName} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Last Name:</label>
                    <input placeholder="Last name" name="lastName" className="form-control" value={this.state.lastName} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>ID Proof:</label>
                    <input type="text" placeholder="ID Proof" name="idproof" className="form-control" value={this.state.idproof} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Current Address:</label>
                    <input type="text" placeholder="Current Address" name="caddress" className="form-control" value={this.state.caddress} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Shipping Address</label>:
                    <input type="text" placeholder="Shipping Address" name="saddress" className="form-control" value={this.state.saddress} onChange={this.onChange}/>
                </div>

                <div className="form-group">
                    <label>Shipping amount:</label>
                    <input type="number" placeholder="Shipping amount" name="samount" className="form-control" value={this.state.samount} onChange={this.onChange}/>
                </div>

                <button className="btn btn-success" onClick={this.saveShipping}>Save</button>
            </form>
    </div>
        );
    }
}

export default AddShippingComponent;