import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class TrackShippingComponent extends Component{

    constructor(props){
        super(props);
        this.state ={
            trackingId: '',
            firstName: '',
            lastName: '',
            caddress: '',
            saddress: '',
            samount: '',
            message: null
        }
        this.trackShipping = this.trackShipping.bind(this);
    }

    trackShipping = (e) => {
        e.preventDefault();
        let shipping = {id: this.state.trackingId};
        ApiService.trackShippingById(shipping.id)
            .then(res => {
                this.setState({message : 'Shipping created successfully.'});
                console.log(res);
                let shipping = res.data.result;
                this.setState({
                    id: shipping.id,
                    firstName: shipping.firstName,
                    lastName: shipping.lastName,
                    caddress: shipping.caddress,
                    saddress: shipping.saddress,
                    samount: shipping.samount,
                    })
                    console.log("id=>",this.state.id);
            });
    }

    onChange = (e) =>
        this.setState({ [e.target.name]: e.target.value });

    render() {
        return(
            <div>
                <h2 className="text-center">Track Shipping</h2>
                <form>
               

                <div className="form-group">
                    <label>Tracking ID:</label>
                    <input placeholder="Tracking Id" name="trackingId" className="form-control" value={this.state.trackingId} onChange={this.onChange}/>
                </div>


                <button className="btn btn-success" onClick={this.trackShipping}>Track</button>
            </form>
            <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Tracking Id</th>
                            <th>FirstName</th>
                            <th>LastName</th>
                            <th>Customer Address</th>
                            <th>Shipping Address</th>
                            <th>Shipping Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                           
                                    <tr key={this.state.id}>
                                        <td>{this.state.id}</td>
                                        <td>{this.state.firstName}</td>
                                        <td>{this.state.lastName}</td>
                                        <td>{this.state.caddress}</td>
                                        <td>{this.state.saddress}</td>
                                        <td>{this.state.samount}</td>
                                    </tr>
                           
                        }
                    </tbody>
                </table>
    </div>
        );
    }
}

export default TrackShippingComponent;