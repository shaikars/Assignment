import React, { Component } from 'react'
import ApiService from "../../service/ApiService";

class MainComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            shippings: [],
            message: null
        }
       
    }

    componentDidMount() {
       
    }

    
    addShipping() {
        window.localStorage.removeItem("shippingId");
        this.props.history.push('/create-shipping');
    }
    findShipping() {
        window.localStorage.removeItem("shippingId");
        this.props.history.push('/track-shipping');
    }

    render() {
        return (
            <div>
                <button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.addShipping()}> Create Shipping</button>&nbsp;&nbsp;&nbsp;
                <button className="btn btn-danger" style={{width:'200px'}} onClick={() => this.findShipping()}> Track Shipping</button>
                
            </div>
        );
    }

}

export default MainComponent;