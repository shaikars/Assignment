package com.shipping.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.shipping.model.Shipping;

@Repository
public interface ShippingDao extends CrudRepository<Shipping, Integer> {

    
}
