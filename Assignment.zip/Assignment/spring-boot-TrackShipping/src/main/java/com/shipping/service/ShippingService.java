package com.shipping.service;

import com.shipping.model.Shipping;
import com.shipping.model.ShippingDto;

public interface ShippingService {
	
	Shipping findById(int id);
    Shipping save(ShippingDto shipping);
    }
