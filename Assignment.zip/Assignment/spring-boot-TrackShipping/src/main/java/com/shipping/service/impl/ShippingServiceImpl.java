package com.shipping.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shipping.dao.ShippingDao;
import com.shipping.model.Shipping;
import com.shipping.model.ShippingDto;
import com.shipping.service.ShippingService;

@Transactional
@Service(value = "shippingService")
public class ShippingServiceImpl implements ShippingService {
	
	@Autowired
	private ShippingDao shippingDao;

	@Override
	public Shipping findById(int id) {
		Optional<Shipping> optionalUser = shippingDao.findById(id);
		return optionalUser.isPresent() ? optionalUser.get() : null;
	}

    @Override
    public Shipping save(ShippingDto user) {
    	Shipping newShipping = new Shipping();
	    newShipping.setIdproof(user.getIdproof());
	    newShipping.setFirstName(user.getFirstName());
	    newShipping.setLastName(user.getLastName());
	    newShipping.setSaddress(user.getSaddress());
		newShipping.setCaddress(user.getCaddress());
		newShipping.setSamount(user.getSamount());
        return shippingDao.save(newShipping);
    }
    
}
