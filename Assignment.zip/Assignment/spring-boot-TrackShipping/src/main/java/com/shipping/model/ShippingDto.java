package com.shipping.model;

public class ShippingDto {

    private int id;
    private String firstName;
    private String lastName;
    private String idproof;
    private String caddress;
    private long samount;
    private String saddress;

    public int getId() {
        return id;
    }

    public ShippingDto(int id, String firstName, String lastName, String idproof, String caddress, long samount,
			String saddress) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idproof = idproof;
		this.caddress = caddress;
		this.samount = samount;
		this.saddress = saddress;
	}

	public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

	public String getIdproof() {
		return idproof;
	}

	public void setIdproof(String idproof) {
		this.idproof = idproof;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public long getSamount() {
		return samount;
	}

	public void setSamount(long samount) {
		this.samount = samount;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

   
}
