package com.shipping.service;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.shipping.dao.ShippingDao;
import com.shipping.model.Shipping;
import com.shipping.service.impl.ShippingServiceImpl;

@ExtendWith(MockitoExtension.class)
class ShippingServiceImplTest {

	@InjectMocks
	ShippingServiceImpl service;
	
	@Mock
	ShippingDao dao;
	
	@Test
	void findById_test() {
		when(dao.findById(anyInt())).thenReturn(this.getShippingData());
		Shipping shipping = service.findById(1);
		Assertions.assertEquals(shipping.getId(),1);
	}

	private Optional<Shipping> getShippingData() {
		Shipping shipping = new Shipping();
		shipping.setId(1);
		return Optional.of(shipping);
	}
}

